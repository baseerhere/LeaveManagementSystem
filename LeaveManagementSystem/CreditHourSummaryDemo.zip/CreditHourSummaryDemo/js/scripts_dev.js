﻿function showSub(obj)
{
	var hiddenQuestion = obj.parentNode.parentNode.getElementsByTagName("OL") [0];
	hiddenQuestion.style.display = "block";
}

function hideSub(obj)
{
	var hiddenQuestion = obj.parentNode.parentNode.getElementsByTagName("OL") [0];
	hiddenQuestion.style.display = "none";
}

function HideElement(id) {
    if(document.getElementById(id)) {
        document.getElementById(id).display = "none";
    }
}

function ShowElement(id) {
    if(document.getElementById(id)) {
        document.getElementById(id).display = "block";
    }
}

function ToggleElement(imageElement, toggleElement, plusImage, minusImage) {
    if(document.getElementById(toggleElement)) {
        if(document.getElementById(toggleElement).style.display == "none") {
            document.getElementById(toggleElement).style.display = "block";
            if(document.getElementById(imageElement) && minusImage != "") {
                document.getElementById(imageElement).src = minusImage;
            }
        } else {
            document.getElementById(toggleElement).style.display = "none";
            if(document.getElementById(imageElement) && plusImage != "") {
                document.getElementById(imageElement).src = plusImage;
            }
        }
    }
}


function validateAnswer(listTag,answer,explanation)
{
	var div = listTag.parentNode.parentNode.parentNode;
	var span = null;
	var explanationContainer = null;

	for(var counter = 0; counter < div.childNodes.length; counter++) {
		if(div.childNodes[counter].nodeName == "SPAN" && (div.childNodes[counter].className == "correct" || div.childNodes[counter].className == "incorrect")) {
			span = div.childNodes[counter];
		}
		
		if(div.childNodes[counter].className == "quiz-explanation"){
			explanationContainer = div.childNodes[counter];
			explanationContainer.innerHTML = explanation;
		}
	}
	
	if(span == null) {
		span = document.createElement("span");
		div.insertBefore(span,explanationContainer);
	}	
	
	if(answer)
	{
		span.className = "correct";
		span.innerHTML = "Correct";
	}
	else
	{
		span.className = "incorrect";
		span.innerHTML = "Incorrect";
	}
	explanationContainer.style.display = "block";
}