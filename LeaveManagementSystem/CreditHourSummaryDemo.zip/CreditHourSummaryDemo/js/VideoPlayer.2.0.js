function VideoPlayer(t, w, h) {
    var globalroot = document.location.hostname;
    var globalplatform = navigator.platform;

    this._root = 'http://' + globalroot;
    this._domain = this.getDomain();
    this._path = this.getPath();

    this._type;
    this._file;
    this._placeholder;
    this._player;
    this._skin;
    this._controlbar;
    this._width;
    this._height;
    this._playlist;
    this._playlistsize;
    this._streamer;
    this._file_h5;
    this._streamer_h5;
    this._placeholder_h5;
    this._abouttext;
    this._aboutlink;
    this._autostart;
    this._vp;

    this._flash = new Object();
    this._html5 = new Object();

    if (t) {
        this.setType(t);
    }
    if (w) {
        this.setWidth(w);
    }
    if (h) {
        this.setHeight(h);
    }

    this._flashinstalled = this.checkFlash();
}

VideoPlayer.prototype.checkFlash = function () {
    var hasFlash = false;
    try {
        var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
        if (fo)
            hasFlash = true;
    } catch (e) {
        if (navigator.mimeTypes["application/x-shockwave-flash"] != undefined)
            hasFlash = true;
    }

    return hasFlash;
}

VideoPlayer.prototype.getDomain = function () {
    var d = document.domain;
    return d;
}

VideoPlayer.prototype.getPath = function () {
    var myloc = window.location.href;
    var locarray = myloc.split("/");
    delete locarray[(locarray.length - 1)];
    var arraytext = locarray.join("/");
    return arraytext;
}

VideoPlayer.prototype.setPlayer = function (str) {
    this._player = str;
}

VideoPlayer.prototype.setSkin = function (str) {
    this._skin = str;
}

VideoPlayer.prototype.setControlbar = function (str) {
    this._controlbar = str;
}

VideoPlayer.prototype.setWidth = function (w) {
    this._width = w;
}

VideoPlayer.prototype.setHeight = function (h) {
    this._height = h;
}

VideoPlayer.prototype.setSize = function (w, h) {
    this.setWidth(w);
    this.setHeight(h);
}

VideoPlayer.prototype.setPlaylist = function (s) {
    this._playlist = s;
}

VideoPlayer.prototype.setAbouttext = function (s) {
    this._abouttext = s;
}

VideoPlayer.prototype.setAboutlink = function (s) {
    this._aboutlink = s;
}

VideoPlayer.prototype.setAutostart = function (s) {
    this._autostart = s;
}

VideoPlayer.prototype.setType = function (t) {
    if (t.toUpperCase() == "FLV" || t.toUpperCase() == "WMV" || t.toUpperCase() == "QT") {
        this._type = t;
    } else {
        this._type = 'FLV.6.4';
        /*
		if (this._file.toUpperCase().indexOf("WMV") > -1) {
			this._type = "WMV";
		} else if (this._file.toUpperCase().indexOf("MOV") > -1) {
			this._type = "QT";
		} else {
			this._type = "FLV";
		}
		*/
    }
}

// FLASH
VideoPlayer.prototype.setFile = function (str) {
    this._file = str;
    this._flash['file'] = str;
}

VideoPlayer.prototype.setPlaceholder = function (str) {
    this._placeholder = str;
    this._flash['placeholder'] = str;
}

VideoPlayer.prototype.setStreamer = function (str) {
    this._streamer = str;
    this._flash['streamer'] = str;
}

// HTML5
VideoPlayer.prototype.setFileH5 = function (str) {
    if (str.indexOf("m3u8") > -1) {
        this._file_h5 = str;
        this._html5['file'] = str;
    } else {
        this._file_h5 = str + '.m3u8';
        this._html5['file'] = str + '.m3u8';
    }
}
VideoPlayer.prototype.setStreamerH5 = function (str) {
    this._streamer_h5 = str;
    this._html5['streamer'] = str;
}
VideoPlayer.prototype.setPlaceholderH5 = function (str) {
    this._placeholder_h5 = str;
    this._html5['placeholder'] = str;
}

VideoPlayer.prototype.setDefaults = function () {
    // alert("DEFAULTS");
    if (!this._type) {
        this.setType(this._file);
    }
    if (!this._file) {
        this.setFile(this._root + '/flashtemplates/vplayer-placeholder-novideo.swf');
    }
    if (!this._player) {
        this.setPlayer(this._root + '/flashtemplates/vplayer-default.swf');
    }
    if (!this._skin) {
        this.setSkin('');
    }
    if (!this._controlbar) {
        this.setControlbar('');
    }
    if (!this._width) {
        this.setWidth(320);
    }
    if (!this._height) {
        this.setHeight(240);
    }
    if (!this._streamer) {
        this.setStreamer('');
    }
    if (!this._abouttext) {
        this.setAbouttext('SmartPros Ltd.');
    }
    if (!this._aboutlink) {
        this.setAboutlink('http://www.smartpros.com');
    }
    if (!this._autostart) {
        this.setAutostart('true');
    }

    if (this._playlist == "bottom") {
        this.setHeight(this._height + 120);
        this.playlistsize = 120;
    } else if (this._playlist == "right") {
        this.setWidth(this._width + 180);
        this.playlistsize = 180;
    } else if (this._playlist == "over") {
        this.setHeight(this._height);
        this.playlistsize = 0;
    } else {
        this._playlist = '';
        this.playlistsize = '';
    }

    if (this._type == "WMV") {

    } else if (this._type == "QT") {

    } else if (this._type == "FLV") {
        if (this._controlbar != 'over' && this._controlbar != 'none') {
            this._height += 20;
        }
    } else {
        if (this._controlbar != 'over' && this._controlbar != 'none') {
            this._height += 20;
        }
    }
}

VideoPlayer.prototype.write = function (div) {
    this.setDefaults();

    var embedcode = "";

    if (this._type == "WMV") {
        var hAdjust;
        var userPlatform = navigator.platform;

        if (userPlatform == "MacIntel" || userPlatform == "MacPPC") {
            hAdjust = 16;
        } else {
            hAdjust = 143;
        }

        embedcode += '<div id="__wmvplayer__">';
        embedcode += '	<OBJECT ID="MediaPlayer" ';
        embedcode += '		WIDTH="' + this._width + '" ';
        embedcode += '		HEIGHT="' + (this._height + hAdjust) + '" ';
        embedcode += '		CLASSID="CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95" ';
        embedcode += '		STANDBY="Loading Windows Media Player components..." ';
        embedcode += '		TYPE="application/x-oleobject">';
        embedcode += '		<PARAM NAME="FileName" VALUE="' + this._file + '">';
        embedcode += '		<PARAM name="ShowControls" VALUE="true">';
        embedcode += '		<param name="ShowStatusBar" value="true">';
        embedcode += '		<PARAM name="ShowDisplay" VALUE="true">';
        embedcode += '		<PARAM name="autostart" VALUE="true">';
        embedcode += '		<EMBED TYPE="application/x-mplayer2" ';
        embedcode += '			SRC="' + this._file + '" ';
        embedcode += '			NAME="MediaPlayer" ';
        embedcode += '			WIDTH="' + this._width + '" ';
        embedcode += '			HEIGHT="' + (this._height + hAdjust) + '" ';
        embedcode += '			ShowControls="1" ';
        embedcode += '			ShowStatusBar="1" ';
        embedcode += '			ShowDisplay="1" ';
        embedcode += '			autostart="1">';
        embedcode += '		</EMBED>';
        embedcode += '	</OBJECT></div>';
    } else if (this._type == "QT") {
        embedcode += '<div id="__qtplayer__">';
        embedcode += '	<OBJECT CLASSID="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" ';
        embedcode += '		CODEBASE="http://www.apple.com/qtactivex/qtplugin.cab" ';
        embedcode += '		WIDTH="' + this._width + '" ';
        embedcode += '		HEIGHT="' + (this._height + 16) + '"> ';
        embedcode += '		<PARAM NAME="src" VALUE="' + this._file + '" > ';
        embedcode += '		<PARAM NAME="AutoPlay" VALUE="true" > ';
        embedcode += '		<PARAM NAME="Controller" VALUE="true" > ';
        embedcode += '		<EMBED SRC="' + this._file + '" ';
        embedcode += '			WIDTH="' + this._width + '" ';
        embedcode += '			HEIGHT="' + (this._height + 16) + '" ';
        embedcode += '			TYPE="video/quicktime" ';
        embedcode += '			PLUGINSPAGE="http://www.apple.com/quicktime/download/" ';
        embedcode += '			AUTOPLAY="true" ';
        embedcode += '			CONTROLLER="true" />';
        embedcode += '	</OBJECT></div>';
    } else if (this._type == "FLV") {
        if (this._flashinstalled) {
            embedcode += '<div id="__flvplayer__">';
            embedcode += '	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" ';
            embedcode += '		codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" ';
            embedcode += '		width="' + this._width + '" ';
            embedcode += '		height="' + this._height + '" ';
            embedcode += '		id="flvplayer" ';
            embedcode += '		align="middle">';
            embedcode += '		<param name="movie" value="' + this._player + '">';
            embedcode += '		<param name="flashvars" value="file=' + this._file + '&autostart=' + this._autostart + '&playlist=' + this._playlist + '&playlistsize=' + this.playlistsize + '&repeat=list&skin=' + this._skin + '&controlbar=' + this._controlbar + '&streamer=' + this._streamer + '&abouttext=' + this._abouttext + '&aboutlink=' + this._aboutlink + '&stretching=uniform"> ';
            embedcode += '		<param name="wmode" value="transparent">';
            embedcode += '		<param name="allowScriptAccess" value="always">';
            embedcode += '		<param name="allowFullScreen" value="true">';
            embedcode += '		<param name="quality" value="high">';
            embedcode += '		<param name="bgcolor" value="#FFFFFF">';
            embedcode += '		<embed src="' + this._player + '" ';
            embedcode += '			flashvars="file=' + this._file + '&autostart=' + this._autostart + '&playlist=' + this._playlist + '&playlistsize=' + this.playlistsize + '&repeat=list&skin=' + this._skin + '&controlbar=' + this._controlbar + '&streamer=' + this._streamer + '&abouttext=' + this._abouttext + '&aboutlink=' + this._aboutlink + '&stretching=uniform" ';
            embedcode += '			quality="high" ';
            embedcode += '			wmode="transparent" ';
            embedcode += '			bgcolor="#FFFFFF" ';
            embedcode += '			width="' + this._width + '" ';
            embedcode += '			height="' + this._height + '" ';
            embedcode += '			name="flvplayer" ';
            embedcode += '			align="middle" ';
            embedcode += '			allowScriptAccess="always" ';
            embedcode += '			allowFullScreen="true" ';
            embedcode += '			type="application/x-shockwave-flash" ';
            embedcode += '			pluginspage="http://www.macromedia.com/go/getflashplayer">';
            embedcode += '	</object>';
            embedcode += '</div>';
        } else if (!this._flashinstalled && (this._streamer_h5 && this._file_h5)) {
            embedcode += '	<video ';
            embedcode += '		width="' + this._width + '" ';
            embedcode += '		height="' + this._height + '" ';
            embedcode += '		controls="controls" ';

            if (this._placeholder_h5) {
                embedcode += '		poster="' + this._html5['placeholder'] + '">';
            } else {
                embedcode += '		autoplay="autoplay">';
            }

            embedcode += '		<source src="' + this._html5['streamer'] + '/' + this._html5['file'] + '.m3u8" type="video/mp4">';
            embedcode += '		Your browser can not play this video.';
            embedcode += '	</video>';
        } else {
            embedcode += '<span class="notice">Your browser cannot play this video.</span>';
        }
    } else {
        // CREATE NEW SCRIPT
        var js = document.createElement('script');
        js.setAttribute('type', 'text/javascript');
        // js.setAttribute('src', 'https://jwpsrv.com/library/8pDvEs0tEeKjSiIACqoQEQ.js');
        js.setAttribute('src', '//content.jwplatform.com/libraries/NQtz4U68.js');

        // ADD LOAD LISTENERS
        if (!js.addEventListener) {
            js.onreadystatechange = function () {
                if (js.readyState == 'loaded' || js.readyState == 'complete') {
                    embedVideoPlayer();
                }
            };
        } else {
            js.addEventListener("load", function () {
                embedVideoPlayer();
            });
        }

        // ADD SCRIPT TO DOCUMENT
        if (!document.head) {
            document.getElementsByTagName('body')[0].appendChild(js);
        } else {
            document.body.appendChild(js);
        }

        var root = this._root;
        var w = this._width;
        var h = this._height;
        var autostart = (this._autostart == 'true') ? true : false;
        var controlbar = this._controlbar;
        var abouttext = this._abouttext;
        var aboutlink = this._aboutlink;

        // var mode = this._flashinstalled ? 'flash' : 'html5';
        var mode = 'html5'; // set to always use html5
        var streamer = this['_' + mode]['streamer'];
        var file = this['_' + mode]['file'];
        var path = streamer + "/" + file;

        if (!this.isMobile()) {
        	path = path.replace('hls-', '').replace('.m3u8', '');
        }
        
        var _this = this;
        
        function embedVideoPlayer() {
            var jw = jwplayer(div).setup({
                file: path,
                width: w,
                height: h,
                controlbar: controlbar,
                abouttext: abouttext,
                aboutlink: aboutlink,
                "autostart": "viewable"
            });

            jw.key = "LpOmx1FTFhAwp9pl4XjhyijcplHKUcfzlNPwtA==";

            _this._vp = jw;
        }

    }

    if (embedcode) {
        if (div) {
            document.getElementById(div).innerHTML = embedcode;
        } else {
            document.write(embedcode);
        }
    }
}

VideoPlayer.prototype.stop = function () {
    this._vp.stop();
}

VideoPlayer.prototype.trace = function (t) {
    alert(t);
}

VideoPlayer.prototype.IncludeJavaScript = function (js) {
    document.write('<script type="text/javascript" src="' + js + '"></scr' + 'ipt>');
}

VideoPlayer.prototype.isMobile = function() {
	if (navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) || this.isAndroid() || this.isKindle() || navigator.userAgent.match(/Blackberry/i))
		return true;
	else
		return false;
}


VideoPlayer.prototype.isAndroid = function() {
	if ((navigator.userAgent.match(/Linux/i) && navigator.userAgent.match(/Chrome/i)) || navigator.userAgent.match(/Android/i))
		return true;
	else
		return false;
}

VideoPlayer.prototype.isKindle = function() {
	if (navigator.userAgent.match(/Silk/i))
		return true;
	else
		return false;
}
