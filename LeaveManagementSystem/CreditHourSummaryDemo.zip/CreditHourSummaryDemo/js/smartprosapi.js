﻿
var coreScoreMax = new String("100");
var coreScoreMin = new String("0");
var coreLessonLocation = new String("");
var suspendData = new String("");
var launchData = new String("SMARTPROS");
var coreSessionTime = new String("");
var coreTotalTime = new String("");
var coreLessonStatus = new String("");
var coreScoreRaw = new String("");
var studentdataMasteryScore = new String("70.00");
var coreCredit = new String("");
var coreLessonMode = new String("");
var coreEntry = new String("");
var coreExit = new String("");
var interactions = new String("");
var previewMode = false;
var StudentName = new String("");

var API = null;
var scormcourselaunched = null;

//API Constructor Call
function Smartpros_API(valId, courseId) {
    
    this.ValID = valId;
    this.CourseID = courseId;
    this.StudentName = "";
    this.StudentID = "";
    this.lastError = 0;
    this.LMSInitialize = smartprosInitialize;
    this.LMSGetLastError = smartprosGetLastError;
    this.LMSGetValue = smartprosGetValue;
    this.LMSSetValue = smartprosSetValue;
    this.LMSCommit = smartprosCommit;
    this.LMSFinish = smartprosFinish;
    this.LMSSetLastError = smartprosSetLastError;
    this.LMSSetValuesOnLaunch = smartprosSetValuesOnLaunch;
}

function courseLaunch(userId, courseId, scormstr, isPreview) {
    API = new Smartpros_API(userId, courseId)

    if (isPreview.toLowerCase() == "true") {
        previewMode = true;
        return;
    }

    if (!API) {
        window.status = 'API not available'
    }
    else {
        API.StudentName = '';
        API.StudentID = userId;
        API.LMSSetValuesOnLaunch(scormstr);
        scormcourselaunched = 1;
        window.status = 'API available'
    }
}   

//Set Scorm course attributes on course launch. The scorm string is generated in a callback to the database and is retrieved in the following format 
//cmi.core.lesson_location=1|||cmi.core.lesson_status=I|||cmi.core.lesson_mode=take|||cmi.core.credit=0.00|||cmi.core.score.raw=0.00
function smartprosSetValuesOnLaunch(str) {
    var i = 0;
    var attributearray = str.split("|||")
    var parametername = new String("");
    for (i = 0; i < attributearray.length; i++) {
        parameterarray = attributearray[i].split("=");
        //alert(parameterarray[0]);
        //alert(parameterarray[1]);
        parametername = parameterarray[0]
        parametername = parametername.toLowerCase()
        switch (parametername) {
            case "cmi.core.lesson_location":
                var loc = parameterarray[1];
                if (loc == '0') { loc = '-1'; }
                coreLessonLocation = loc;
                break;

            case "cmi.core.total_time":
                coreTotalTime = parameterarray[1];
                break;

            case "cmi.core.session_time":
                coreSessionTime = parameterarray[1];
                break;

            case "cmi.core.lesson_status":
                var stat = parameterarray[1];
                //if ( stat == 'C' || stat == 'c') { stat = 'passed'}
                //else if ( stat == 'I' || stat == 'i') { stat = 'incomplete'}
                coreLessonStatus = stat;
                break;

            case "cmi.core.score.raw":
                coreScoreRaw = parameterarray[1];
                break;

            case "cmi.core.lesson_mode":
                coreLessonMode = parameterarray[1];
                break;

            case "cmi.core.credit":
                coreCredit = parameterarray[1];
                break;

            case "cmi.student_data.mastery_score":
                studentdataMasteryScore = parameterarray[1];
                break;

            case "cmi.suspend_data":
                suspendData = unescape(parameterarray[1]);
                break;

            case "cmi.launch_data":
                launchData = parameterarray[1];
                break;

            case "cmi.core.entry":
                coreEntry = parameterarray[1];
                break;

            case "cmi.core.exit":
                coreExit = parameterarray[1];
                break;

            case "cmi.interactions":
                interactions = parameterarray[1];
                break;
            case "cmi.core.student_name":
                this.StudentName = parameterarray[1];
                break;
            default:
                //
                break;
        }
    }
}

//This is the LMS Initialize call
function smartprosInitialize() {
    if (previewMode)
        return;
    
    //database call to validate and set progress markers
    // reset all of the attribute values from db or to null
    window.status = "API Initializing";
    window.status = "API Commiting atributes.";
    var setstring = new String("");
    
    setstring = "studentId=" + this.StudentID;
    setstring += "|||courseId=" + this.CourseID;
    setstring += "|||score=" + coreScoreRaw;
    setstring += "|||time=" + coreSessionTime;
    setstring += "|||status=" + coreLessonStatus;
    setstring += "|||lesson_location=" + coreLessonLocation;
    setstring += "|||suspend_data=" + suspendData;
    setstring += "|||entry=" + coreEntry;
    setstring += "|||exit=" + coreExit;
    setstring += "|||interactions=" + interactions;
    setstring += "|||totaltime=" + coreTotalTime;
    setstring += "|||studentname=" + this.StudentName;

    callServer("LMSInitialize", this.StudentID.toString() + '|||' + this.CourseID.toString(), this.StudentID, this.CourseID);

    return initResult;
    //scormCallback("LMSInitialize:", this.StudentID.toString() + '|||' + this.CourseID.toString());
}

function smartprosGetLastError() {
    return this.lastError;
}

function smartprosSetLastError(error) {
    this.lastError = error;
}

//Sets course values to the Scorm course attributes
function smartprosSetValue(attribute, tValue) {

    //alert(attribute + " - " + tValue)
    var parametername = new String("");
    window.status = "Setting " + attribute + " to " + tValue;
    var parametername = attribute;
    parametername = parametername.toLowerCase();
    switch (parametername) {
        case "cmi.core.score.max":
            coreScoreMax = tValue;
            break;

        case "cmi.core.score.min":
            coreScoreMin = tValue;
            break;

        case "cmi.core.lesson_location":
            coreLessonLocation = tValue;
            break;

        case "cmi.interactions":
            interactions = tValue;
            break;

        case "cmi.suspend_data":
            suspendData = escape(tValue);
            break;

        case "cmi.launch_data":
            launchData = tValue;
            break;

        case "cmi.core.session_time":
            coreSessionTime = tValue;
            break;

        case "cmi.core.lesson_status":
            coreLessonStatus = tValue;
            break;

        case "cmi.core.score.raw":
            coreScoreRaw = tValue;
            break;

        case "cmi.core.exit":
            coreExit = tValue;
            break;

        case "cmi.core.entry":
            coreEntry = tValue;
            break;

        case "cmi.core.total_time":
            coreTotalTime = tValue;
            break;

        case "cmi.core.student_name":
            this.StudentName = tValue;
            break;
        default:
            //
            break;
    }
    return "true";
}

//Utilized by the course to retrieve specific attributes of the course from the database.
function smartprosGetValue(attribute) {

    //alert(attribute)
    switch (attribute) {
        case "cmi.core._children":
            return ("student_id,student_name,lesson_location,credit,lesson_status,entry,score,total_time,exit,session_time,lesson_mode");
            break;

        case "cmi.objectives._children":
            return ("id,status,score");
            break;

        case "cmi.launch_data":
            return (launchData);
            break;

        case "cmi.core.score.max":
            return (coreScoreMax);
            break;

        case "cmi.core.score.min":
            return (coreScoreMin);
            break;

        case "cmi.core.lesson_mode":
            return (coreLessonMode);
            break;

        case "cmi.core.lesson_location":
            return (coreLessonLocation);
            break;

        case "cmi.suspend_data":
            return (unescape(suspendData));
            break;

        case "cmi.core.total_time":
            return (coreTotalTime);
            break;

        case "cmi.core.lesson_status":
            return (coreLessonStatus);
            break;

        case "cmi.core.score.raw":
            return (coreScoreRaw);
            break;

        case "cmi.core.exit":
            return (coreExit)
            break;

        case "cmi.core.entry":
            return (coreEntry)
            break;

        case "cmi.student_data.mastery_score":
            return (studentdataMasteryScore);
            break;

        case "cmi.core.credit":
            return (coreCredit);
            break;

        case "cmi.core.student_name":
            return (this.StudentName);
            break;

        case "cmi.core.student_id":
            return (this.StudentID);
            break;

        case "cmi.interactions":
            return (interactions);
            break;

        default:
            //
            break;
    }
    return ("true");
}

//This method is responsible for committing the values of the course to the Database. The method it calls is the scormCallback(), which is a Callback method generated at runtime. This method calls the Server side method RaiseCallbackEvent() in Player.aspx.cs
function smartprosCommit(valStr) {

    if (previewMode)
        return;

    window.status = "API Commiting atributes.";
    var setstring = new String("");
    //    if (document.fmAPIPostBack) {
    //        document.fmAPIPostBack.lmsAction.value = "LMSCommit";
    //        document.fmAPIPostBack.lmsSession.value = this.StudentID + '|||' + this.CourseID;
    setstring = "studentId=" + this.StudentID;
    setstring += "|||courseId=" + this.CourseID;
    setstring += "|||score=" + coreScoreRaw;
    setstring += "|||time=" + coreSessionTime;
    setstring += "|||status=" + coreLessonStatus;
    setstring += "|||lesson_location=" + coreLessonLocation;
    setstring += "|||suspend_data=" + suspendData;
    setstring += "|||entry=" + coreEntry;
    setstring += "|||exit=" + coreExit;
    setstring += "|||interactions=" + interactions;
    setstring += "|||totaltime=" + coreTotalTime;
    setstring += "|||studentname=" + this.StudentName;
    //        document.fmAPIPostBack.lmsValue.value = setstring;
    //        document.fmAPIPostBack.submit();

    callServer("LMSCommit", setstring, this.StudentID, this.CourseID);

    return commitResult;
    //scormCallback("LMSCommit:" + setstring, "");
    //    }
    //    else {
    //        window.status = "API Not Commiting";
    //        return "false";
    //    }
    //    return ("true");
}

function smartprosFinish(valStr) {
    if (previewMode)
        return;
    
    smartprosFinish

    this.StudentName = "";
    window.status = "API Finishing";
    var setstring = new String("");
    //    if (document.fmAPIPostBack) {
    //        document.fmAPIPostBack.lmsAction.value = "LMSFinish";
    //        // here put together a string of courseid and studentid and the other values to commit
    //    document.fmAPIPostBack.lmsSession.value = this.StudentID + '|||' + this.CourseID;

    setstring = "studentId=" + this.StudentID;
    setstring += "|||courseId=" + this.CourseID;
    setstring += "|||score=" + coreScoreRaw;
    setstring += "|||time=" + coreSessionTime;
    setstring += "|||status=" + coreLessonStatus;
    setstring += "|||lesson_location=" + coreLessonLocation;
    setstring += "|||suspend_data=" + suspendData;
    setstring += "|||entry=" + coreEntry;
    setstring += "|||exit=" + coreExit;
    setstring += "|||interactions=" + interactions;
    setstring += "|||totaltime=" + coreTotalTime;
    setstring += "|||studentname=" + this.StudentName;

    //document.fmAPIPostBack.lmsValue.value = setstring;
    //document.fmAPIPostBack.submit();

    callServer("LMSFinish", setstring, this.StudentID, this.CourseID); 

    //scormCallback("LMSFinish:" + setstring, "");

    clearScormVariables();

    return finishResult;
    //    }
    //    else {
    //        window.status = "API Not Finished";
    //        return "false";
    //    }
    //    return ("true");
}

function receiveScormData(result) {
    //WI 48155 : SCORM courses not scoring properly
    var callType = result.d.split(':')[0];
    var apiResult = result.d.split(':')[1];

    if (apiResult == "")
        window.status = "Error making API Callback";

    if (callType == "LMSInitialize") {
        initResult = "true";
        return;
    }
    else if (callType == "LMSCommit") {
        if (apiResult == "0") {
            commitResult = "true";
            return;
        }
        else {
            window.status = "API Not Commiting"
            commitResult = "false";
            return;
        }
    }
    else if (callType == "LMSFinish") {
        if (apiResult == "0") {
            finishResult = "true";
            return;
        }
        else {
            window.status = "API Not Finished";
            finishResult = "false";
            return;
        }
    }
}

function clearScormVariables() {
    this.ValID = "";
    this.CourseID = "";
    this.StudentName = "";
    this.StudentID = "";
    this.lastError = 0;
    coreScoreMax = "100";
    coreScoreMin = "0";
    coreLessonLocation = "";
    suspendData = "";
    launchData = "SMARTPROS";
    coreSessionTime = "";
    coreTotalTime = "";
    coreLessonStatus = "";
    coreScoreRaw = "";
    coreCredit = "";
    coreLessonMode = "";
    studentdataMasteryScore = "70.00";
    coreEntry = "";
    coreExit = "";
    interactions = "";
    API = null;
}