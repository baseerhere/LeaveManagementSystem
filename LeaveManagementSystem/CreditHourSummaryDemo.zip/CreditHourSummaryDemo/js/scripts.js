/* Global Variables*/

var redirectToPlaylist;
var coursePlayerOpen;
/*******************/
function dyniframesize(flashid) {
    //do nothing   
}
function showSub(obj) {
    var hiddenQuestion = obj.parentNode.parentNode.getElementsByTagName("OL")[0];
    hiddenQuestion.style.display = "block";
}

function hideSub(obj) {
    var hiddenQuestion = obj.parentNode.parentNode.getElementsByTagName("OL")[0];
    hiddenQuestion.style.display = "none";
}

function HideElement(id) {
    if (document.getElementById(id)) {
        document.getElementById(id).display = "none";
    }
}

function ShowElement(id) {
    if (document.getElementById(id)) {
        document.getElementById(id).display = "block";
    }
}

function ToggleElement(toggleElement, imageElement, plusImage, minusImage) {
    if (document.getElementById(toggleElement)) {
        if (document.getElementById(toggleElement).style.display == "none") {
            document.getElementById(toggleElement).style.display = "block";
            if (document.getElementById(imageElement) && minusImage != "") {
                document.getElementById(imageElement).src = minusImage;
            }
        } else {
            document.getElementById(toggleElement).style.display = "none";
            if (document.getElementById(imageElement) && plusImage != "") {
                document.getElementById(imageElement).src = plusImage;
            }
        }
    }
}

function addClass(id, newclass) {
    if (document.getElementById(id)) {
        document.getElementById(id).className += " " + newclass;
    }
}

function validateAnswer(listTag, answer, explanation) {

    var div = listTag.parentNode.parentNode.parentNode;
    var span = null;
    var explanationContainer = null;

    for (var counter = 0; counter < div.childNodes.length; counter++) {
        if (div.childNodes[counter].nodeName == "SPAN" && (div.childNodes[counter].className == "correct" || div.childNodes[counter].className == "incorrect")) {
            span = div.childNodes[counter];
        }

        if (div.childNodes[counter].className == "quiz-explanation") {
            explanationContainer = div.childNodes[counter];
            explanationContainer.innerHTML = explanation;
        }
    }

    if (span == null) {
        span = document.createElement("span");
        div.insertBefore(span, explanationContainer);
    }

    if (answer) {
        span.className = "correct";
        span.innerHTML = "Correct";

        if (LastPage == false) {
            if (btnNext.disabled == true) {
                btnNext.disabled = false;
                btnNext.className = "btnBackbtnNext btnNext";
            }
        }
    }
    else {
        span.className = "incorrect";
        span.innerHTML = "Incorrect";
    }
    explanationContainer.style.display = "block";


}

function ReplaceCSSForFlash() {
    var theBox = document.getElementById("playerDiv");
    theBox.id = "playerDiv1";

    var theBox1 = document.getElementById("content");
    theBox1.id = "content1";

    document.getElementById("top-nav").innerHTML = '<div  visible="false">';
    document.getElementById("course-heading").innerHTML = '<div visible="false">';

}

//This function add the function event once page is get loaded. 
function addLoadListener(fn) {
    var browserName = navigator.appName;
    if (typeof window.addEventListener != 'undefined') {
        window.addEventListener('load', fn, false);
    }
    else if (typeof document.addEventListener != 'undefined') {
        document.addEventListener('load', fn, false);
    }
    else if (browserName == "Microsoft Internet Explorer") {
        if (typeof window.attachEvent != 'undefined') {
            window.attachEvent('onload', fn);
        }
    }
    else {
        var oldfn = window.onload;
        if (typeof window.onload != 'function') {
            window.onload = fn;
        }
        else {
            window.onload = function () {
                oldfn();
                fn();
            };
        }
    }
}

function showLoadingSpinner(showit) {
    switch (showit) {
        case false:
            $('#loading-spinner').remove();
            $('html').css('overflow', 'auto');
            break;

        default:
            $('body').append('<div id="loading-spinner"></div>');
            $('html').css('overflow', 'hidden');
            $('#loading-spinner').click(function () {
                showLoadingSpinner(false);
            });
            break;
    }
}

function recordCourseLaunch() {
    coursePlayerOpen = true;
}

function resetCourseLaunch() {
    coursePlayerOpen = false;
}

function redirectToCourseListing(productGroupId) {
    //setting a global variable indicating that the course was redirected to the playlist    
    redirectToPlaylist = true;

    location.href = '../mycourses/myplaylistcatalog.aspx?Launch=' + productGroupId;
}

if (typeof jQuery !== 'undefined') {
    (function ($, root, undefined) {

        $(function () {

            'use strict';

            // SELECT FIELDS UNDER DEFAULT UI
            $('.default-ui select').each(function (index) {
                var s = $(this);
                var v = s.val();

                if (v == '' || v == ' ' || v == -1 || !v)
                    s.addClass('not-selected');
                else
                    s.removeClass('not-selected');
            });
            $('.default-ui select').change(function () {
                var s = $(this);
                var v = s.val();

                if (v == '' || v == ' ' || v == -1 || !v)
                    s.addClass('not-selected');
                else
                    s.removeClass('not-selected');
            });

            // TELERIK DATE PICKERS
            $('.riTextBox').each(function (index) {
                var s = $(this);
                var v = s.val();
                var p = s.data('placeholder') ? s.data('placeholder') : 'Select Date';

                if (v == '' || v == ' ' || v == -1 || !v) {
                    s.addClass('not-selected');
                    // s.val('Select Date');
                    s.val(p);
                } else {
                    s.removeClass('not-selected');
                }
            });
            $('.riTextBox').focusout(function () {
                var s = $(this);
                var v = s.val();
                var p = s.data('placeholder') ? s.data('placeholder') : 'Select Date';

                if (v == '' || v == ' ' || v == -1 || !v) {
                    s.addClass('not-selected');
                    // s.val('Select Date');
                    s.val(p);
                } else {
                    s.removeClass('not-selected');
                }
            });

            /*
			// ADVANCED SEARCH START DATE
			$('#ctl00_ctl00_cphContent_cphContent_ReleaseDatePicker_dateInput').each(function (index) {
				var s = $(this);
				var v = s.val();
				var p = s.data('placeholder') ? s.data('placeholder') : 'Select date';

				if (v == '' || v == ' ' || v == -1 || !v) {
					s.addClass('not-selected');
					// s.val('Start Date');
					s.val(p);
				} else {
					s.removeClass('not-selected');
				}
			});
			$('#ctl00_ctl00_cphContent_cphContent_ReleaseDatePicker_dateInput').focusout(function () {
				var s = $(this);
				var v = s.val();
				var p = s.data('placeholder') ? s.data('placeholder') : 'Select date';

				if (v == '' || v == ' ' || v == -1 || !v) {
					s.addClass('not-selected');
					// s.val('Start Date');
					s.val(p);
				} else {
					s.removeClass('not-selected');
				}
			});
			
			// ADVANCED SEARCH END DATE
			$('#ctl00_ctl00_cphContent_cphContent_ReleaseEndPicker_dateInput').each(function (index) {
				var s = $(this);
				var v = s.val();
				var p = s.data('placeholder') ? s.data('placeholder') : 'Select date';

				if (v == '' || v == ' ' || v == -1 || !v) {
					s.addClass('not-selected');
					// s.val('End Date');
					s.val(p);
				} else {
					s.removeClass('not-selected');
				}
			});
			$('#ctl00_ctl00_cphContent_cphContent_ReleaseEndPicker_dateInput').focusout(function () {
				var s = $(this);
				var v = s.val();
				var p = s.data('placeholder') ? s.data('placeholder') : 'Select date';

				if (v == '' || v == ' ' || v == -1 || !v) {
					s.addClass('not-selected');
					// s.val('End Date');
					s.val(p);
				} else {
					s.removeClass('not-selected');
				}
			});
			*/
        });

    })(jQuery, this);
}
